/**
 * STAGE — Official Landing Page JavaScript Engine
 * Powered by GSAP, ScrollTrigger & Web Audio API
 */

document.addEventListener('DOMContentLoaded', () => {
  // Initialize Sound FX Engine
  initAudio();

  // Initialize Theme Switcher
  initTheme();

  // Initialize GSAP Animations & ScrollTriggers
  initGSAPAnimations();

  // Initialize Interactive Sandbox & Mockup Phones
  initInteractivePhoneSandbox();

  // Initialize Handle Availability Checker
  initHandleChecker();

  // Initialize Merchant ROI Calculator
  initRoiCalculator();

  // Initialize FAQ Accordion
  initFaqAccordion();

  // Initialize Live Activity Toast Notifications
  initLiveToasts();

  // Initialize Early Access Form & Confetti
  initEarlyAccessForm();
});

/* ==========================================================================
   1. Audio Synthesizer Engine (Zero external assets needed)
   ========================================================================== */
let audioCtx = null;
let soundEnabled = true;

function initAudio() {
  const soundBtn = document.getElementById('soundToggleBtn');
  if (!soundBtn) return;

  soundBtn.addEventListener('click', () => {
    soundEnabled = !soundEnabled;
    soundBtn.innerHTML = soundEnabled 
      ? `<svg viewBox="0 0 24 24"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>`
      : `<svg viewBox="0 0 24 24"><path d="M11 5L6 9H2v6h4l5 4V5z"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>`;
    
    if (soundEnabled) {
      playSound('pop');
    }
  });
}

function playSound(type) {
  if (!soundEnabled) return;
  try {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }

    const now = audioCtx.currentTime;
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);

    if (type === 'pop') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.08);
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
      osc.start(now);
      osc.stop(now + 0.08);
    } else if (type === 'chime') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(587.33, now); // D5
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.2); // A5
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      osc.start(now);
      osc.stop(now + 0.25);
    } else if (type === 'curtain') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(220, now);
      osc.frequency.exponentialRampToValueAtTime(330, now + 0.4);
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
      osc.start(now);
      osc.stop(now + 0.4);
    } else if (type === 'success') {
      // Harmonic chord
      [523.25, 659.25, 783.99, 1046.50].forEach((freq, i) => {
        const o = audioCtx.createOscillator();
        const g = audioCtx.createGain();
        o.type = 'sine';
        o.frequency.setValueAtTime(freq, now + i * 0.06);
        g.gain.setValueAtTime(0.12, now + i * 0.06);
        g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.06 + 0.35);
        o.connect(g);
        g.connect(audioCtx.destination);
        o.start(now + i * 0.06);
        o.stop(now + i * 0.06 + 0.35);
      });
    }
  } catch (e) {
    // Audio context may be restricted before user gesture
  }
}

/* ==========================================================================
   2. Theme Switcher (Dark / Light)
   ========================================================================== */
function initTheme() {
  const themeBtn = document.getElementById('themeToggleBtn');
  const savedTheme = localStorage.getItem('stage-theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);

  updateThemeIcon(savedTheme);

  if (themeBtn) {
    themeBtn.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme');
      const next = current === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', next);
      localStorage.setItem('stage-theme', next);
      updateThemeIcon(next);
      playSound('pop');
    });
  }
}

function updateThemeIcon(theme) {
  const btn = document.getElementById('themeToggleBtn');
  if (!btn) return;
  if (theme === 'dark') {
    btn.innerHTML = `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>`;
  } else {
    btn.innerHTML = `<svg viewBox="0 0 24 24"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>`;
  }
}

/* ==========================================================================
   3. GSAP Animations & ScrollTriggers
   ========================================================================== */
function initGSAPAnimations() {
  if (typeof gsap === 'undefined') return;

  // Register ScrollTrigger if available
  if (typeof ScrollTrigger !== 'undefined') {
    gsap.registerPlugin(ScrollTrigger);
  }

  // Header Sticky Effect
  window.addEventListener('scroll', () => {
    const header = document.querySelector('.site-header');
    if (header) {
      if (window.scrollY > 40) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    }
  });

  // Hero Section Staggered Entrance
  const heroTl = gsap.timeline({ defaults: { ease: 'power3.out', duration: 0.9 } });

  heroTl
    .from('.hero-pill-badge', { y: 20, opacity: 0, delay: 0.2 })
    .from('.hero-title', { y: 30, opacity: 0 }, '-=0.6')
    .from('.hero-description', { y: 20, opacity: 0 }, '-=0.6')
    .from('.handle-claim-box', { y: 20, opacity: 0 }, '-=0.6')
    .from('.hero-social-proof', { y: 15, opacity: 0 }, '-=0.5')
    .from('.hero-phone-container', { y: 40, opacity: 0, scale: 0.96 }, '-=0.8')
    .from('.floating-hero-badge', { scale: 0, opacity: 0, stagger: 0.2, ease: 'back.out(1.7)' }, '-=0.4');

  // ScrollTrigger reveals for sections and cards
  if (typeof ScrollTrigger !== 'undefined') {
    gsap.utils.toArray('.reveal-on-scroll').forEach(el => {
      gsap.from(el, {
        scrollTrigger: {
          trigger: el,
          start: 'top 85%',
          toggleActions: 'play none none none'
        },
        y: 40,
        opacity: 0,
        duration: 0.8,
        ease: 'power2.out'
      });
    });

    gsap.utils.toArray('.feature-row').forEach(row => {
      gsap.from(row.children, {
        scrollTrigger: {
          trigger: row,
          start: 'top 80%'
        },
        y: 50,
        opacity: 0,
        stagger: 0.2,
        duration: 0.9,
        ease: 'power3.out'
      });
    });
  }
}

/* ==========================================================================
   4. Interactive Phone Sandbox Engine (All 5 Live Mobile Experiences)
   ========================================================================== */
function initInteractivePhoneSandbox() {
  // Shared status bar template
  const SB = '<div class="sb"><span>9:41</span><i class="isl"></i><svg class="sbi" viewBox="0 0 60 12" aria-hidden="true"><use href="#i-status"/></svg></div>';
  const NAVS = [['home', 'Home'], ['search', 'Explore'], ['users', 'Following'], ['bag', 'Cart'], ['box', 'Orders']];
  const ico = (id, c = '') => `<svg class="ic ${c}" aria-hidden="true"><use href="#i-${id}"/></svg>`;
  const fmt = n => '₦' + n.toLocaleString('en-US');

  // Decorate all phones with status bar & bottom nav
  document.querySelectorAll('.phone').forEach(p => {
    if (!p.querySelector('.sb')) {
      p.insertAdjacentHTML('afterbegin', SB);
    }
    const n = p.dataset.nav;
    if (n && !p.querySelector('.nav')) {
      const on = n === 'home' ? 'home' : 'search';
      p.insertAdjacentHTML('beforeend', '<nav class="nav" aria-label="Main">' + NAVS.map(([i, l]) => `<button class="${i === on ? 'on' : ''}" aria-label="${l}">${ico(i)}${i === 'bag' ? '<span class="badge">3</span>' : ''}</button>`).join('') + '</nav>');
    }
  });

  // Sandbox Tab Switching
  const sandboxTabs = document.querySelectorAll('.sandbox-tab-btn');
  const sandboxPanels = document.querySelectorAll('.sandbox-panel');

  sandboxTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const target = tab.dataset.target;
      sandboxTabs.forEach(t => t.classList.toggle('active', t === tab));
      sandboxPanels.forEach(p => p.classList.toggle('active', p.id === target));
      playSound('pop');
    });
  });

  /* ----------------------------------------------------
     EXPERIENCE 1: Masonry Home Feed
     ---------------------------------------------------- */
  const AV = {
    bc: ['BC', "Bella's Closet"],
    kj: ['KJ', 'Kicks by Jay'],
    gm: ['GM', 'Gifted by Mimi'],
    wp: ['WP', 'The Wardrobe Plug'],
    cl: ['CL', 'Chic Looks']
  };

  const PINS = [
    { k: 'photo', t: ['Fashion', 'Following'], imgs: ['model'], ar: 0.78, title: 'Black two-piece', price: '₦25,000', biz: 'bc', custom: true },
    { k: 'photo', t: ['Fashion', 'Following'], imgs: ['whitetop'], ar: 0.92, title: 'White peplum top', price: '₦12,000', biz: 'bc' },
    { k: 'text', t: ['Gifts'] },
    { k: 'photo', t: ['Gifts', 'Following'], imgs: ['candle'], ar: 0.84, title: 'Amber glow candle', price: '₦8,500', biz: 'gm', custom: true },
    { k: 'shout', t: ['Fashion', 'Bags', 'Following'], biz: 'kj' },
    { k: 'photo', t: ['Gifts', 'Following'], imgs: ['gift'], ar: 0.96, title: 'Blush gift box', price: '₦18,000', biz: 'gm' },
    { k: 'photo', t: ['Fashion'], imgs: ['coord', 'outfit', 'dress'], ar: 0.86, title: 'The Noir edit', badge: '12 products', biz: 'cl' },
    { k: 'biz', t: ['Fashion', 'Bags'], biz: 'wp', thumbs: ['bagblack', 'tote', 'dress'] },
    { k: 'photo', t: ['Bags'], imgs: ['bagblack'], ar: 0.95, title: 'Structured handbag', price: '₦42,000', biz: 'wp' },
    { k: 'blush', t: ['Gifts', 'Fashion'] },
    { k: 'photo', t: ['Bags'], imgs: ['tote'], ar: 0.7, title: 'Mini shoulder bag', price: '₦22,000', biz: 'wp' }
  ];

  const H = { photo: p => 155 / p.ar + 62, text: 214, blush: 214, shout: 206, biz: 236 };

  function pinHTML(p) {
    if (p.k === 'text') return `<article class="tp"><div><h3>Gifts that say “I thought of you.”</h3><p>38 gift shops are on Stage right now.</p></div><button class="pill">Browse gifts</button></article>`;
    if (p.k === 'blush') return `<article class="tp blush"><div><h3>Add a name to it.</h3><p>Personalised picks, made to order and ready in 3 days.</p></div><button class="pill">See custom picks</button></article>`;
    if (p.k === 'shout') return `<article class="sh"><div class="mg">${ico('mega', 'md')}</div><h3>Back in stock!</h3><p>Kicks by Jay just restocked 18 sneakers.</p><div class="ft"><span class="av kj">KJ</span><button class="mini">View Stage</button></div></article>`;
    if (p.k === 'biz') {
      const [i, n] = AV[p.biz];
      return `<article class="bz"><div class="bz-g">${p.thumbs.map(t => `<i style="background-image:var(--img-${t})"></i>`).join('')}</div><div class="bz-r"><span class="av lg ${p.biz}">${i}</span><div><b>${n}</b><small>32 products</small></div></div><button class="follow">Follow</button></article>`;
    }
    const [i, n] = AV[p.biz], car = p.imgs.length > 1;
    return `<article class="pin"><div class="pimg" style="aspect-ratio:${p.ar};background-image:var(--img-${p.imgs[0]})" ${car ? `data-car="${p.imgs.join(',')}" data-i="0"` : ''}>
      ${p.custom ? `<span class="cust">${ico('spark', 'sm fill')}Customizable</span>` : ''}
      <button class="heart" aria-label="Save ${p.title}">${ico('heart')}</button>
      <span class="price">${p.badge || p.price}</span></div>
      ${car ? `<div class="dots">${p.imgs.map((_, j) => `<i class="${j ? '' : 'on'}"></i>`).join('')}</div>` : ''}
      <div class="pt">${p.title}</div>
      <div class="pm"><span class="av ${p.biz}">${i}</span><span class="bn">${n}</span><button class="more" aria-label="More options">${ico('dots', 'fill')}</button></div></article>`;
  }

  const TABS = ['For you', 'Following', 'Fashion', 'Gifts', 'Bags'];
  
  document.querySelectorAll('.phone-feed-container').forEach(feedCont => {
    const tabsEl = feedCont.querySelector('.tabs');
    const colsEl = feedCont.querySelector('.cols');
    const homeScroll = feedCont.querySelector('.scroll');
    if (!tabsEl || !colsEl) return;

    tabsEl.innerHTML = TABS.map((t, i) => `<button class="tab ${i ? '' : 'on'}" role="tab" aria-selected="${!i}">${t}</button>`).join('');

    function renderFeed(tab) {
      const list = tab === 'For you' ? PINS : PINS.filter(p => p.t.includes(tab));
      const cols = [[], []], hs = [0, 0];
      list.forEach(p => {
        const c = hs[0] <= hs[1] ? 0 : 1;
        cols[c].push(pinHTML(p));
        hs[c] += (typeof H[p.k] === 'function' ? H[p.k](p) : H[p.k]);
      });
      colsEl.innerHTML = cols.map(c => `<div class="col">${c.join('')}</div>`).join('');
    }

    renderFeed('For you');

    tabsEl.addEventListener('click', e => {
      const b = e.target.closest('.tab');
      if (!b) return;
      tabsEl.querySelectorAll('.tab').forEach(x => {
        x.classList.toggle('on', x === b);
        x.setAttribute('aria-selected', x === b);
      });
      renderFeed(b.textContent);
      if (homeScroll) homeScroll.scrollTo({ top: 0, behavior: 'smooth' });
      playSound('pop');
    });

    colsEl.addEventListener('click', e => {
      const h = e.target.closest('.heart');
      if (h) {
        h.classList.toggle('on');
        playSound('chime');
        return;
      }
      const f = e.target.closest('.follow');
      if (f) {
        const on = f.classList.toggle('on');
        f.textContent = on ? 'Following' : 'Follow';
        playSound('pop');
        return;
      }
      const img = e.target.closest('.pimg[data-car]');
      if (img) {
        const arr = img.dataset.car.split(',');
        const n = (+img.dataset.i + 1) % arr.length;
        img.dataset.i = n;
        img.style.backgroundImage = `var(--img-${arr[n]})`;
        img.parentElement.querySelectorAll('.dots i').forEach((d, j) => d.classList.toggle('on', j === n));
        playSound('pop');
      }
    });
  });

  /* ----------------------------------------------------
     EXPERIENCE 2: Shout Bubbles Cosmos
     ---------------------------------------------------- */
  const COL = { Fashion: '#40214B', Gifts: '#EE9A22', Decor: '#8FA07A', Beauty: '#E38F84', Food: '#C8693D', Tech: '#2F6F73' };
  const OY = 40;
  const B = [
    { n: "Bella's Closet", c: 'Fashion', city: 'Lagos', s: 118, x: 90, y: 92, img: 'model', pos: '50% 12%', say: '12 new pieces!', bl: 'Everyday pieces made for the modern woman. Chic, comfortable, timeless.' },
    { n: 'Gifted by Mimi', c: 'Gifts', city: 'Port Harcourt', s: 96, x: 226, y: 84, img: 'gift', say: 'Gift sets 10% off', bl: 'Thoughtful gifts for every occasion, wrapped and ready to send.' },
    { n: 'Kicks by Jay', c: 'Fashion', city: 'Lagos', s: 84, x: 236, y: 190, img: 'sneak', say: 'Back in stock!', bl: 'Clean sneakers and everyday shoes. 18 pairs restocked this morning.' },
    { n: 'The Wardrobe Plug', c: 'Fashion', city: 'Port Harcourt', s: 104, x: 104, y: 222, img: 'bagblack', say: 'New bags just landed', bl: 'Bags, tops and dresses picked for how you actually dress.' },
    { n: 'Amber & Oak', c: 'Decor', city: 'Abuja', s: 88, x: 184, y: 310, img: 'candle', say: 'Candles restocked', bl: 'Hand-poured candles and warm home touches. Names can be added on request.' },
    { n: 'Glow Theory', c: 'Beauty', city: 'Lagos', s: 78, x: 60, y: 330, logo: 'GT', bg: '#F4C9BE', fg: '#40214B', say: 'Free sample with every order', bl: 'Skincare basics that work with your routine, not against it.' },
    { n: 'Chic Looks', c: 'Fashion', city: 'Ibadan', s: 60, x: 268, y: 322, logo: 'CL', bg: '#40214B', fg: '#EE9A22', say: 'New in tonight', bl: 'Sharp co-ords and easy dresses for work and weekends.' },
    { n: 'Naija Bites', c: 'Food', city: 'Abuja', s: 74, x: 78, y: 430, logo: 'NB', bg: '#F0C89A', fg: '#5a2b12', say: 'Fresh batch at 4 pm', bl: 'Small-batch snacks and party trays, baked to order.' },
    { n: 'Volt Hub', c: 'Tech', city: 'Lagos', s: 82, x: 190, y: 420, logo: 'VH', bg: '#2F6F73', fg: '#F3EAD9', say: 'Power banks in stock', bl: 'Chargers, earbuds and power banks with a 6-month warranty.' },
    { n: 'Tayo Interiors', c: 'Decor', city: 'Port Harcourt', s: 62, x: 268, y: 414, logo: 'TI', bg: '#C9D3B8', fg: '#3b4a2b', say: 'Rugs on sale', bl: 'Rugs, cushions and mirrors for rooms that feel finished.' }
  ];

  const field = document.getElementById('field');
  const sheet = document.getElementById('sheet');
  const shFollow = document.getElementById('shFollow');
  let curBubble = null;

  if (field) {
    B.forEach((b, i) => {
      const el = document.createElement('button');
      el.type = 'button';
      el.className = 'bub';
      el.setAttribute('aria-label', `${b.n}, ${b.c}. ${b.say}`);
      el.style.cssText = `--s:${b.s}px;--ring:${COL[b.c]};--dur:${(6 + (i % 4) * 1.3).toFixed(1)}s;--dl:${-(i * 1.7).toFixed(1)}s;left:${b.x - b.s / 2}px;top:${b.y + OY - b.s / 2}px`;
      const face = b.img ? `style="background-image:var(--img-${b.img});background-position:${b.pos || 'center'}"` : `style="background:${b.bg};color:${b.fg}"`;
      el.innerHTML = `<span class="bub-in ${b.img ? 'ph' : ''}" ${face}>${b.img ? '' : `<span class="lg">${b.logo}</span>`}<span class="nm">${b.n}</span></span>`;
      b.el = el;
      b.inner = el.firstElementChild;
      field.appendChild(el);
      el.addEventListener('click', () => openBubbleSheet(b));
    });

    [[26, 52, 16, -1], [152, 56, 12, -3], [24, 236, 20, -2], [142, 482, 14, -4], [262, 500, 18, -5], [30, 500, 12, -2]].forEach(([x, y, s, d]) => {
      const m = document.createElement('i');
      m.className = 'mini-b';
      m.style.cssText = `--s:${s}px;left:${x}px;top:${y + OY - 40}px;--dl:${d}s;--dur:${5 + Math.abs(d)}s`;
      field.appendChild(m);
    });

    const shout = document.createElement('div');
    shout.className = 'shout';
    shout.setAttribute('aria-hidden', 'true');
    field.appendChild(shout);

    const TK = '<svg class="tk l" viewBox="0 0 18 18"><path d="M7 2 9 7M2 9l5 1.5M11 1l.6 5"/></svg><svg class="tk r" viewBox="0 0 18 18"><path d="M7 2 9 7M2 9l5 1.5M11 1l.6 5"/></svg>';
    let order = B.map((_, i) => i).sort(() => Math.random() - 0.5);
    let oi = 0, hideT, paused = false;

    function say(b, keep) {
      shout.innerHTML = `${TK}<b>${b.say}</b><span>${b.n}</span>`;
      shout.classList.remove('on');
      shout.style.left = '0px';
      shout.style.top = '0px';
      const w = shout.offsetWidth, h = shout.offsetHeight, fw = field.clientWidth;
      const left = Math.max(2, Math.min(b.x - w / 2, fw - w - 2));
      shout.style.left = left + 'px';
      shout.style.top = (b.y + OY - b.s / 2 - h - 12) + 'px';
      shout.style.setProperty('--tx', Math.max(16, Math.min(w - 16, b.x - left)) + 'px');
      requestAnimationFrame(() => shout.classList.add('on'));
      B.forEach(x => x.inner.classList.toggle('pop', x === b));
      clearTimeout(hideT);
      if (!keep) {
        hideT = setTimeout(() => {
          shout.classList.remove('on');
          b.inner.classList.remove('pop');
        }, 2400);
      }
    }

    function tick() {
      if (paused) return;
      const vis = order.map(i => B[i]).filter(b => !b.el.classList.contains('dim'));
      if (vis.length) say(vis[oi++ % vis.length]);
    }

    setTimeout(tick, 600);
    setInterval(tick, 3400);

    const chips = document.getElementById('chips');
    if (chips) {
      chips.addEventListener('click', e => {
        const ch = e.target.closest('.chip');
        if (!ch) return;
        chips.querySelectorAll('.chip').forEach(x => x.classList.toggle('on', x === ch));
        const cat = ch.dataset.cat;
        B.forEach(b => b.el.classList.toggle('dim', cat !== 'All' && b.c !== cat));
        shout.classList.remove('on');
        B.forEach(x => x.inner.classList.remove('pop'));
        oi = 0;
        setTimeout(tick, 450);
        playSound('pop');
      });
    }

    function openBubbleSheet(b) {
      curBubble = b;
      paused = true;
      say(b, true);
      const av = document.getElementById('shAv');
      av.style.cssText = b.img ? `background-image:var(--img-${b.img});background-position:${b.pos || 'center'}` : `background:${b.bg};color:${b.fg}`;
      av.textContent = b.img ? '' : b.logo;
      document.getElementById('shName').textContent = b.n;
      document.getElementById('shMeta').textContent = `${b.c} · ${b.city}`;
      document.getElementById('shBlurb').textContent = b.bl;
      shFollow.textContent = b.f ? 'Following' : 'Follow';
      shFollow.className = 'btn-app ' + (b.f ? 'line' : 'solid');
      sheet.classList.add('open');
      sheet.setAttribute('aria-hidden', 'false');
      playSound('chime');
    }

    function closeBubbleSheet() {
      sheet.classList.remove('open');
      sheet.setAttribute('aria-hidden', 'true');
      paused = false;
      shout.classList.remove('on');
      B.forEach(x => x.inner.classList.remove('pop'));
    }

    const sheetX = document.getElementById('sheetX');
    if (sheetX) sheetX.addEventListener('click', closeBubbleSheet);

    if (shFollow) {
      shFollow.addEventListener('click', () => {
        if (!curBubble) return;
        curBubble.f = !curBubble.f;
        shFollow.textContent = curBubble.f ? 'Following' : 'Follow';
        shFollow.className = 'btn-app ' + (curBubble.f ? 'line' : 'solid');
        playSound('pop');
      });
    }
  }

  /* ----------------------------------------------------
     EXPERIENCE 3: Shop The Look
     ---------------------------------------------------- */
  const LOOK = [
    { n: 'Halter crop top', b: "Bella's Closet", p: 12000, x: 47, y: 14, bg: '46% 5%' },
    { n: 'Wide-leg trousers', b: "Bella's Closet", p: 18500, x: 44, y: 52, bg: '42% 52%' },
    { n: 'Mini shoulder bag', b: 'The Wardrobe Plug', p: 22000, x: 19, y: 69, bg: '9% 73%' }
  ];

  const look = document.getElementById('look');
  const lcard = document.getElementById('lcard');
  const itemsEl = document.getElementById('items');
  const added = new Set();
  let selLook = -1;

  if (look && itemsEl) {
    LOOK.forEach((it, i) => {
      const h = document.createElement('button');
      h.className = 'hs';
      h.style.cssText = `left:${it.x}%;top:${it.y}%`;
      h.setAttribute('aria-label', `${it.n}, ${fmt(it.p)}`);
      h.innerHTML = '<i></i>';
      h.addEventListener('click', () => selectLookItem(i));
      look.appendChild(h);
      it.hs = h;
    });

    itemsEl.innerHTML = LOOK.map((it, i) => `<li class="it" data-i="${i}"><span class="lthumb" style="background-position:${it.bg}"></span><div class="txt"><b>${it.n}</b><small>${it.b}</small></div><span class="pr">${fmt(it.p)}</span><button class="addb" aria-label="Add ${it.n} to bag">${ico('plus')}</button></li>`).join('');

    function selectLookItem(i) {
      selLook = i;
      const it = LOOK[i];
      LOOK.forEach((x, j) => x.hs.classList.toggle('on', j === i));
      itemsEl.querySelectorAll('.it').forEach((r, j) => r.classList.toggle('on', j === i));
      const t = document.getElementById('lcThumb');
      t.style.backgroundPosition = it.bg;
      document.getElementById('lcName').textContent = it.n;
      document.getElementById('lcBiz').textContent = it.b;
      document.getElementById('lcPrice').textContent = fmt(it.p);
      lcard.classList.add('show');
      paintLook();
      playSound('pop');
    }

    function toggleLookItem(i) {
      if (added.has(i)) {
        added.delete(i);
      } else {
        added.add(i);
        playSound('chime');
      }
      paintLook();
    }

    function paintLook() {
      itemsEl.querySelectorAll('.addb').forEach((b, j) => {
        const on = added.has(j);
        b.classList.toggle('on', on);
        b.innerHTML = ico(on ? 'check' : 'plus');
      });
      const a = document.getElementById('lcAdd');
      const on = selLook >= 0 && added.has(selLook);
      if (a) {
        a.classList.toggle('on', on);
        a.innerHTML = ico(on ? 'check' : 'plus');
      }
      const left = LOOK.filter((_, j) => !added.has(j));
      const cta = document.getElementById('lookCta');
      if (cta) {
        if (!added.size) cta.textContent = `Add all 3 · ${fmt(LOOK.reduce((s, x) => s + x.p, 0))}`;
        else if (left.length) cta.textContent = `Add remaining ${left.length} · ${fmt(left.reduce((s, x) => s + x.p, 0))}`;
        else cta.textContent = 'All 3 in your cart · View cart';
      }
    }

    const lcAdd = document.getElementById('lcAdd');
    if (lcAdd) lcAdd.addEventListener('click', () => { if (selLook >= 0) toggleLookItem(selLook); });

    itemsEl.addEventListener('click', e => {
      const li = e.target.closest('.it');
      if (!li) return;
      const i = +li.dataset.i;
      if (e.target.closest('.addb')) toggleLookItem(i);
      else selectLookItem(i);
    });

    const lookCta = document.getElementById('lookCta');
    if (lookCta) {
      lookCta.addEventListener('click', () => {
        if (added.size < LOOK.length) {
          LOOK.forEach((_, j) => added.add(j));
          paintLook();
          playSound('success');
        }
      });
    }
    paintLook();
  }

  /* ----------------------------------------------------
     EXPERIENCE 4: Drop Night Theatre
     ---------------------------------------------------- */
  const theatre = document.getElementById('theatre');
  const peek = document.getElementById('peek');
  if (theatre && peek) {
    peek.addEventListener('click', () => {
      const o = theatre.classList.toggle('open');
      peek.textContent = o ? 'Close the curtain' : 'Peek behind the curtain';
      playSound('curtain');
    });
  }

  let dropSeconds = 2 * 3600 + 14 * 60 + 37;
  const p2 = n => String(n).padStart(2, '0');
  setInterval(() => {
    dropSeconds = dropSeconds > 0 ? dropSeconds - 1 : 0;
    const hh = document.getElementById('hh');
    const mm = document.getElementById('mm');
    const ss = document.getElementById('ss');
    if (hh) hh.textContent = p2(Math.floor(dropSeconds / 3600));
    if (mm) mm.textContent = p2(Math.floor((dropSeconds % 3600) / 60));
    if (ss) ss.textContent = p2(dropSeconds % 60);
  }, 1000);

  const remind = document.getElementById('remind');
  if (remind) {
    remind.addEventListener('click', () => {
      const on = remind.classList.toggle('line');
      remind.classList.toggle('solid', !on);
      remind.innerHTML = (on ? ico('check', 'md') : ico('bell', 'md')) + `<span>${on ? 'Reminder set' : 'Remind me'}</span>`;
      playSound('chime');
    });
  }

  document.querySelectorAll('.bell').forEach(b => {
    b.addEventListener('click', () => {
      const on = b.classList.toggle('on');
      b.innerHTML = ico(on ? 'check' : 'bell', 'md');
      playSound('chime');
    });
  });

  /* ----------------------------------------------------
     EXPERIENCE 5: Make It Yours (Live Customizer)
     ---------------------------------------------------- */
  const lbl = document.getElementById('lbl');
  const nm = document.getElementById('nm');
  const jar = document.getElementById('jar');
  const custCta = document.getElementById('custCta');

  const FONTS = {
    script: { fam: "'Pinyon Script', cursive", w: 400, k: 0.42, max: 42, up: false, dy: 6 },
    serif: { fam: "'Fraunces', Georgia, serif", w: 600, k: 0.56, max: 30, up: false, dy: 2 },
    block: { fam: "'Bricolage Grotesque', sans-serif", w: 800, k: 0.68, max: 24, up: true, dy: 0 }
  };

  let currentFont = 'script';

  function drawLabel() {
    if (!lbl || !nm) return;
    const raw = nm.value.trim();
    const f = FONTS[currentFont];
    const txt = raw || 'Your name';
    const shown = f.up ? txt.toUpperCase() : txt;
    const fs = Math.min(f.max, 84 / (Math.max(shown.length, 1) * f.k));
    lbl.textContent = shown;
    lbl.setAttribute('font-size', fs.toFixed(1));
    lbl.setAttribute('y', (158 + f.dy).toFixed(1));
    lbl.style.fontFamily = f.fam;
    lbl.style.fontWeight = f.w;
    lbl.setAttribute('fill-opacity', raw ? '1' : '0.35');
    if (custCta) {
      custCta.textContent = `Add to Cart · ${fmt(8500 + (raw ? 1500 : 0))}`;
    }
  }

  if (nm) nm.addEventListener('input', drawLabel);

  const fontsContainer = document.getElementById('fonts');
  if (fontsContainer) {
    fontsContainer.addEventListener('click', e => {
      const b = e.target.closest('button');
      if (!b) return;
      currentFont = b.dataset.f;
      fontsContainer.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b));
      drawLabel();
      playSound('pop');
    });
  }

  const swContainer = document.getElementById('sw');
  if (swContainer) {
    swContainer.addEventListener('click', e => {
      const b = e.target.closest('button');
      if (!b) return;
      swContainer.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b));
      if (jar) jar.setAttribute('fill', getComputedStyle(b).getPropertyValue('--c').trim());
      const swName = document.getElementById('swName');
      if (swName) swName.textContent = b.dataset.n;
      playSound('pop');
    });
  }

  drawLabel();
}

/* ==========================================================================
   5. Interactive Brand Handle Checker
   ========================================================================== */
function initHandleChecker() {
  const input = document.getElementById('brandHandleInput');
  const status = document.getElementById('handleStatusBadge');
  const btn = document.getElementById('claimHandleBtn');

  if (!input || !status) return;

  let debounceTimer;
  input.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    const val = input.value.trim().toLowerCase().replace(/[^a-z0-9_-]/g, '');
    input.value = val;

    if (val.length >= 2) {
      status.textContent = 'Checking...';
      status.style.display = 'block';
      debounceTimer = setTimeout(() => {
        status.textContent = `@${val} is available! 🎉`;
        status.style.color = '#059669';
        status.style.backgroundColor = 'rgba(16, 185, 129, 0.12)';
      }, 300);
    } else {
      status.style.display = 'none';
    }
  });

  if (btn) {
    btn.addEventListener('click', () => {
      const val = input.value.trim();
      if (!val) {
        input.focus();
        return;
      }
      const emailForm = document.getElementById('earlyAccessEmail');
      if (emailForm) {
        emailForm.scrollIntoView({ behavior: 'smooth' });
        emailForm.focus();
      }
      showToast(`🎯 Handle @${val} locked! Complete your email to claim.`);
      playSound('success');
    });
  }
}

/* ==========================================================================
   6. Creator ROI & Growth Calculator
   ========================================================================== */
function initRoiCalculator() {
  const ordersSlider = document.getElementById('calcOrders');
  const aovSlider = document.getElementById('calcAov');
  const dropFreqSelect = document.getElementById('calcDrops');

  const ordersVal = document.getElementById('calcOrdersVal');
  const aovVal = document.getElementById('calcAovVal');
  const revOutput = document.getElementById('calcRevenueOutput');
  const hoursOutput = document.getElementById('calcHoursOutput');

  if (!ordersSlider || !aovSlider || !revOutput) return;

  function recalculate() {
    const orders = parseInt(ordersSlider.value, 10);
    const aov = parseInt(aovSlider.value, 10);
    const dropMultiplier = dropFreqSelect ? parseFloat(dropFreqSelect.value) : 1.4;

    ordersVal.textContent = `${orders} orders`;
    aovVal.textContent = `₦${aov.toLocaleString()}`;

    // Base GMV
    const currentGmv = orders * aov;
    // Estimated boost from Shop the Look bundling (+25%) and Drop Night hype (+15-40%)
    const boostFactor = 0.38 * dropMultiplier;
    const projectedNewRevenue = Math.round(currentGmv * (1 + boostFactor));

    revOutput.textContent = `₦${projectedNewRevenue.toLocaleString()}`;
    if (hoursOutput) {
      // Estimated hours saved from automated cart, no DM invoicing
      const hrsSaved = Math.round(orders * 0.35);
      hoursOutput.textContent = `${hrsSaved} hrs/mo`;
    }
  }

  ordersSlider.addEventListener('input', recalculate);
  aovSlider.addEventListener('input', recalculate);
  if (dropFreqSelect) dropFreqSelect.addEventListener('change', recalculate);

  recalculate();
}

/* ==========================================================================
   7. FAQ Accordion
   ========================================================================== */
function initFaqAccordion() {
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const q = item.querySelector('.faq-question');
    if (!q) return;
    q.addEventListener('click', () => {
      const isActive = item.classList.contains('active');
      faqItems.forEach(x => x.classList.remove('active'));
      if (!isActive) {
        item.classList.add('active');
        playSound('pop');
      }
    });
  });
}

/* ==========================================================================
   8. Live Social Proof Toast Engine
   ========================================================================== */
const TOAST_EVENTS = [
  { icon: '🛍️', title: 'New order in Lekki', desc: "Amara bought 'Black two-piece' from Bella's Closet" },
  { icon: '🔥', title: 'Drop Night Alert', desc: '142 people set reminder for The Midnight Set' },
  { icon: '🫧', title: 'Live Shout', desc: 'Kicks by Jay just restocked 18 sneakers' },
  { icon: '✨', title: 'Custom Order', desc: "Custom 'Amber glow candle' ordered in Abuja" },
  { icon: '👗', title: 'Lookbook Bundle', desc: 'All 3 pieces added in 1 tap from Lagos' }
];

function initLiveToasts() {
  const container = document.getElementById('liveToastContainer');
  if (!container) return;

  let index = 0;
  function triggerNextToast() {
    const event = TOAST_EVENTS[index % TOAST_EVENTS.length];
    index++;
    showToast(event.desc, event.title, event.icon);
    setTimeout(triggerNextToast, 9000 + Math.random() * 4000);
  }

  setTimeout(triggerNextToast, 4000);
}

function showToast(desc, title = 'Activity on Stage', icon = '✨') {
  const container = document.getElementById('liveToastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = 'live-toast';
  toast.innerHTML = `
    <div class="toast-icon">${icon}</div>
    <div class="toast-body">
      <b>${title}</b>
      <span>${desc}</span>
    </div>
  `;

  container.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add('show'));

  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 400);
  }, 4500);
}

/* ==========================================================================
   9. Early Access Waitlist Form & Confetti Celebration
   ========================================================================== */
function initEarlyAccessForm() {
  const form = document.getElementById('earlyAccessForm');
  if (!form) return;

  form.addEventListener('submit', e => {
    e.preventDefault();
    const emailInput = form.querySelector('input[type="email"]');
    const email = emailInput ? emailInput.value : '';

    if (!email) return;

    // Trigger celebration
    launchConfetti();
    playSound('success');

    form.innerHTML = `
      <div style="padding: 16px; text-align: center; color: var(--gold); font-weight: 700; font-size: 16px;">
        🎉 You're on the VIP list! Check your inbox shortly for your Stage Creator invitation.
      </div>
    `;

    showToast(`VIP Invite sent to ${email}`, 'Welcome to Stage!', '🎟️');
  });
}

function launchConfetti() {
  // Pure canvas confetti effect
  const canvas = document.createElement('canvas');
  canvas.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:99999;';
  document.body.appendChild(canvas);

  const ctx = canvas.getContext('2d');
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;

  const particles = [];
  const colors = ['#EE9A22', '#40214B', '#F4C9BE', '#B9C6A6', '#E2532F', '#FAF4E8'];

  for (let i = 0; i < 90; i++) {
    particles.push({
      x: canvas.width / 2,
      y: canvas.height / 2,
      vx: (Math.random() - 0.5) * 16,
      vy: (Math.random() - 0.7) * 16,
      size: Math.random() * 8 + 4,
      color: colors[Math.floor(Math.random() * colors.length)],
      alpha: 1,
      rot: Math.random() * 360,
      vrot: (Math.random() - 0.5) * 12
    });
  }

  let frame = 0;
  function animate() {
    frame++;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    let alive = false;

    particles.forEach(p => {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.35; // gravity
      p.alpha -= 0.012;
      p.rot += p.vrot;

      if (p.alpha > 0) {
        alive = true;
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate((p.rot * Math.PI) / 180);
        ctx.globalAlpha = Math.max(0, p.alpha);
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
        ctx.restore();
      }
    });

    if (alive && frame < 180) {
      requestAnimationFrame(animate);
    } else {
      canvas.remove();
    }
  }

  requestAnimationFrame(animate);
}
